package test.a;

public class AAA {
    public AAA(){
        System.out.println("AAA-2 constructor");
    }
}
