package test.b;

import test.a.AAA;

public class BBB extends AAA {
    public BBB(){
        super();
        System.out.println("BBB-2 constructor");
    }
}
