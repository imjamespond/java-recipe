package test.c;

import test.b.BBB;

public class CCC {

    public CCC(){
        new BBB();
    }
}
