package org.copycat.framework;

import org.springframework.util.Assert;
import org.springframework.validation.Errors;

public class ValidationUtils {

	public static void rejectIfEmpty(Errors errors, String field, String message) {
		Assert.notNull(errors, "Errors object must not be null");
		Object value = errors.getFieldValue(field);
		if (value == null || value.toString().isEmpty()) {
			errors.rejectValue(field, null, message);
		}
	}

	public static void rejectIfLess(Errors errors, String field,
			String message, int length) {
		Assert.notNull(errors, "Errors object must not be null");
		Object value = errors.getFieldValue(field);
		if (value == null || value.toString().isEmpty()
				|| value.toString().length() < length) {
			errors.rejectValue(field, null, message);
		}
	}

	public static void rejectIfGreat(Errors errors, String field,
			String message, int length) {
		Assert.notNull(errors, "Errors object must not be null");
		Object value = errors.getFieldValue(field);
		if (value == null || value.toString().length() > length) {
			errors.rejectValue(field, null, message);
		}
	}
}
